package com.sxd.myapplication1;

import android.view.View;
import android.widget.Button;

/**
 * Created by SXD on 2016/11/25.
 */

public class Homepage implements View.OnClickListener {



    Homepage(){

    }

    @Override
    public void onClick(View view) {

    }
}
